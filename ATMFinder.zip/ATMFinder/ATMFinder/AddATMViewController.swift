//
//  AddATMViewController.swift
//  ATMFinder
//
//  Created by Yogesh Bhatt on 4/21/19.
//  Copyright © 2019 Yogesh Bhatt. All rights reserved.
//

import UIKit

var banks:[Bank] = [Bank]()

class AddATMViewController: UIViewController {

    @IBOutlet weak var bankName: UITextField!
    @IBOutlet weak var atmLocation: UITextField!
    @IBOutlet weak var workingStatus: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func submitButtonClicked(_ sender: Any) {
        let bankInfo = Bank(bankName:bankName.text!, location: atmLocation.text!, status: workingStatus.text!)
        banks.append(bankInfo)
        bankName.text = ""
        atmLocation.text = ""
        workingStatus.text = ""
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
