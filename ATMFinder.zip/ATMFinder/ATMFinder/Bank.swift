//
//  Bank.swift
//  ATMFinder
//
//  Created by Yogesh Bhatt on 4/21/19.
//  Copyright © 2019 Yogesh Bhatt. All rights reserved.
//

import UIKit

class Bank: NSObject {
    let bankName:String
    let location:String
    let status:String
    
    init(bankName:String, location:String, status:String) {
        self.bankName = bankName
        self.location = location
        self.status = status
    }
}
