//
//  LogInViewController.swift
//  ATMFinder
//
//  Created by Yogesh Bhatt on 4/21/19.
//  Copyright © 2019 Yogesh Bhatt. All rights reserved.
//

import UIKit

class LogInViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func submitButtonClicked(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
       let nextViewController = storyBoard.instantiateViewController(withIdentifier: "AddATMViewController") as! AddATMViewController
//        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "SearchATMViewController") as! SearchATMViewController

        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
