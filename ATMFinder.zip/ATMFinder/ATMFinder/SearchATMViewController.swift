//
//  SearchATMViewController.swift
//  ATMFinder
//
//  Created by Yogesh Bhatt on 4/21/19.
//  Copyright © 2019 Yogesh Bhatt. All rights reserved.
//

import UIKit

class SearchATMViewController: UIViewController, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var workingStatus: UITextField!
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var bankName: UITextField!
    
    var banksArray:[Bank] = [Bank]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.searchBar.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    //MARK: UISearchbar delegate
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
      return true
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let object = banks.filter { $0.bankName == searchBar.text || $0.location == searchBar.text || $0.status == searchBar.text
        }
        banksArray = object
//        workingStatus.text = object?.status
//        location.text = object?.location
//        bankName.text = object?.bankName
        tableView.reloadData()
        
    }
    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool  {
        tableView.reloadData()
        return true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if (banksArray.count) > 0 {
            return banksArray.count
        }else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell: UITableViewCell = {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell") else {
                // Never fails:
                return UITableViewCell(style: UITableViewCell.CellStyle.value1, reuseIdentifier: "cellReuseIdentifier")
            }
            return cell
        }()
        
        let bank = banksArray[indexPath.row] //2.
        
        cell.textLabel?.text = bank.bankName //3.
        cell.detailTextLabel?.text = bank.location
        
        return cell //4.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
