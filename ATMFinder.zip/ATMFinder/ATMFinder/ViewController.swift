//
//  ViewController.swift
//  ATMFinder
//
//  Created by Yogesh Bhatt on 4/21/19.
//  Copyright © 2019 Yogesh Bhatt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

